module.exports = {
    bemvindo: (req, res) => {
        res.send("rodando")
    }
}