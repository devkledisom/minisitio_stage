import React from "react";

const Map = () => {
    return (
        <div className="map-main">
            <h1>test mapa</h1>
        </div>
    )
};

export default Map;